"""TanStack-based panels."""

"""AI interface for interacting with various LLM providers."""

from collections.abc import AsyncGenerator, Callable
from typing import Any

from langchain_anthropic import ChatAnthropic
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage, BaseMessage, HumanMessage, SystemMessage
from langchain_core.runnables import Runnable
from langchain_core.tools import BaseTool
from langchain_openai import AzureChatOpenAI

from .config import ModelConfig, ProviderConfig, parse_model_value

# ---------------------------------------------------------------------------
# Provider registry: maps client_type strings to factory functions.
# Each factory receives (provider, model_name, temperature, max_tokens)
# and returns a BaseChatModel.
#
# env_vars values are already resolved (no os.getenv needed here).
# ---------------------------------------------------------------------------

_ClientFactory = Callable[[ProviderConfig, str, float, int], BaseChatModel]

# Models that reject the ``temperature`` parameter. Claude Opus 4.7 samples
# adaptively and returns 400 "temperature is deprecated for this model" if
# temperature is sent. Extend this set as Anthropic expands the list.
_TEMPERATURE_FREE_MODELS = frozenset({"claude-opus-4-7"})


def _model_supports_temperature(model_name: str) -> bool:
    """Return False for models that reject the ``temperature`` parameter."""
    return model_name not in _TEMPERATURE_FREE_MODELS


def _create_anthropic_client(
    provider: ProviderConfig,
    model_name: str,
    temperature: float,
    max_tokens: int,
) -> BaseChatModel:
    """Create a ChatAnthropic instance from provider config."""
    api_key = provider.env_vars.get("api_key", "")
    endpoint = provider.env_vars.get("endpoint", "")

    # dict[str, Any] (not `object`): these values are passed straight through to
    # ChatAnthropic's pydantic-validated constructor, whose individual keyword
    # parameters accept a variety of concrete types (str, bool, float, ...). Typing
    # this as `object` made every one of them look incompatible to ty; `Any` reflects
    # that the values are genuinely heterogeneous and pydantic validates them at runtime.
    kwargs: dict[str, Any] = {
        "model_name": model_name,
        "max_tokens_to_sample": max_tokens,
        "anthropic_api_key": api_key,
        "base_url": endpoint,
    }
    if _model_supports_temperature(model_name):
        kwargs["temperature"] = temperature

    return ChatAnthropic(**kwargs)


def _create_azure_openai_client(
    provider: ProviderConfig,
    model_name: str,
    temperature: float,
    max_tokens: int,
) -> BaseChatModel:
    """Create an AzureChatOpenAI instance from provider config."""
    _ = max_tokens  # Azure OpenAI does not use max_tokens at init

    api_key = provider.env_vars.get("api_key", "")
    endpoint = provider.env_vars.get("endpoint", "")
    api_version = provider.env_vars.get("api_version", "")

    return AzureChatOpenAI(  # type: ignore[call-arg]
        azure_deployment=model_name,
        temperature=temperature,
        openai_api_key=api_key,
        azure_endpoint=endpoint,
        openai_api_version=api_version,
    )


PROVIDER_CLASS_REGISTRY: dict[str, _ClientFactory] = {
    "anthropic": _create_anthropic_client,
    "azure_openai": _create_azure_openai_client,
}


class AiInterface:
    """Interface for interacting with AI models.

    This class provides a unified interface for working with different LLM providers,
    supporting streaming responses, tool usage, and conversation history management.

    Attributes:
        model: The underlying chat model instance
        provider: The model provider being used
        tools: List of tools available to the model
        conversation_history: List of messages in the conversation
        system_message: Optional system message for the conversation
    """

    def __init__(
        self,
        provider: ProviderConfig,
        model_name: str | ModelConfig,
        temperature: float = 0.7,
        max_tokens: int = 4096,
        tools: list[BaseTool] | None = None,
        system_message: str | None = None,
    ) -> None:
        """Initialize the AI interface.

        Args:
            provider: The provider configuration
            model_name: The specific model to use (string or ModelConfig)
            temperature: Sampling temperature (0-1)
            max_tokens: Maximum tokens in response
            tools: Optional list of LangChain tools
            system_message: Optional system message for the conversation
        """
        self.provider = provider
        self.tools = tools or []
        self.conversation_history: list[BaseMessage] = []
        self.system_message = system_message

        # Extract model name string from ModelConfig if needed, then strip
        # any LiteLLM provider prefix so LangChain receives bare model names.
        raw_value = model_name.value if isinstance(model_name, ModelConfig) else model_name
        _, model_name_str = parse_model_value(raw_value)

        # Initialize the appropriate model
        base_model = self._initialize_model(
            provider=provider,
            model_name=model_name_str,
            temperature=temperature,
            max_tokens=max_tokens,
        )

        # Bind tools to model if provided
        self.model: Runnable[Any, Any] = base_model.bind_tools(self.tools) if self.tools else base_model

    @staticmethod
    def _initialize_model(
        provider: ProviderConfig,
        model_name: str,
        temperature: float,
        max_tokens: int,
    ) -> BaseChatModel:
        """Initialize the chat model based on provider.

        Args:
            provider: The provider configuration
            model_name: The model name
            temperature: Sampling temperature
            max_tokens: Maximum tokens

        Returns:
            Initialized chat model

        Raises:
            ValueError: If provider is not supported or required env vars are missing
        """
        factory = PROVIDER_CLASS_REGISTRY.get(provider.client_type)
        if factory is None:
            msg = f"Unsupported client_type: {provider.client_type}"
            raise ValueError(msg)
        return factory(provider, model_name, temperature, max_tokens)

    def add_tool(self, tool: BaseTool) -> None:
        """Add a tool to the interface.

        Args:
            tool: LangChain tool to add
        """
        self.tools.append(tool)
        # Rebind all tools to the model. `self.model` is typed as the generic
        # `Runnable[Any, Any]` (it may be a `RunnableBinding` proxying attribute
        # access to the underlying chat model via `__getattr__`, e.g. after a
        # previous `bind_tools()` call), so `bind_tools` isn't a statically known
        # attribute here; use getattr for the dynamic dispatch this depends on.
        bind_tools = getattr(self.model, "bind_tools", None)
        if bind_tools is not None:
            self.model = bind_tools(self.tools)

    def clear_history(self) -> None:
        """Clear the conversation history."""
        self.conversation_history = []

    def _build_messages(self, user_message: str, history: list[BaseMessage] | None = None) -> list[BaseMessage]:
        """Build the message list for the model.

        Args:
            user_message: The user's message
            history: Conversation context; defaults to the instance history.

        Returns:
            List of messages including system, history, and current user message
        """
        if history is None:
            history = self.conversation_history
        messages: list[BaseMessage] = []

        # Add system message if provided
        if self.system_message:
            messages.append(SystemMessage(content=self.system_message))

        # Add conversation history
        messages.extend(history)

        # Add current user message
        messages.append(HumanMessage(content=user_message))

        return messages

    async def get_response(
        self, user_message: str, stream: bool = True, history: list[BaseMessage] | None = None
    ) -> str | AsyncGenerator[str, None]:
        """Get a response from the AI model.

        Args:
            user_message: The user's input message
            stream: Whether to stream the response
            history: Conversation context to read and append to; defaults to
                the instance history. Passing an explicit list keeps
                concurrent conversations isolated from each other.

        Returns:
            Either a complete response string or an async generator for streaming

        Raises:
            Exception: If the model invocation fails
        """
        if history is None:
            history = self.conversation_history

        # Build messages
        messages = self._build_messages(user_message, history=history)

        # Add user message to history
        history.append(HumanMessage(content=user_message))

        if stream:
            return self._stream_response(messages, history=history)
        else:
            # Non-streaming response
            response = await self.model.ainvoke(messages)
            response_text = response.content if isinstance(response.content, str) else str(response.content)

            # Add AI response to history
            history.append(AIMessage(content=response_text))

            return response_text

    async def _stream_response(
        self, messages: list[BaseMessage], history: list[BaseMessage] | None = None
    ) -> AsyncGenerator[str, None]:
        """Stream response from the model.

        Args:
            messages: List of messages to send to the model
            history: Conversation context the response is appended to.

        Yields:
            Chunks of the response text
        """
        if history is None:
            history = self.conversation_history
        full_response = ""

        async for chunk in self.model.astream(messages):
            if hasattr(chunk, "content") and chunk.content:
                content = chunk.content if isinstance(chunk.content, str) else str(chunk.content)
                full_response += content
                yield content

        # Add complete response to history
        history.append(AIMessage(content=full_response))

    async def get_response_with_tools(
        self, user_message: str, history: list[BaseMessage] | None = None
    ) -> dict[str, Any]:
        """Get a response that may include tool calls.

        Args:
            user_message: The user's input message
            history: Conversation context; defaults to the instance history.

        Returns:
            Dictionary containing response text and any tool calls

        Raises:
            Exception: If the model invocation fails
        """
        if history is None:
            history = self.conversation_history
        messages = self._build_messages(user_message, history=history)

        # Add user message to history
        history.append(HumanMessage(content=user_message))

        # Invoke model
        response = await self.model.ainvoke(messages)

        # Extract response content and tool calls
        response_text = response.content if isinstance(response.content, str) else str(response.content)
        tool_calls = getattr(response, "tool_calls", [])

        # Add AI response to history
        history.append(AIMessage(content=response_text, tool_calls=tool_calls))

        return {
            "text": response_text,
            "tool_calls": tool_calls,
        }


def create_interface(
    provider: ProviderConfig,
    model: str | ModelConfig,
    temperature: float = 0.7,
    max_tokens: int = 4096,
    system_message: str | None = None,
    tools: list[BaseTool] | None = None,
) -> AiInterface:
    """Create an AI interface for any configured provider.

    Args:
        provider: The provider configuration
        model: The model to use (string or ModelConfig)
        temperature: Sampling temperature
        max_tokens: Maximum tokens in response
        system_message: Optional system message
        tools: Optional list of tools

    Returns:
        Configured AiInterface instance
    """
    return AiInterface(
        provider=provider,
        model_name=model,
        temperature=temperature,
        max_tokens=max_tokens,
        tools=tools,
        system_message=system_message,
    )
